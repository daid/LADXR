from LADXRSecret.mapgen import generate
import random

random.seed(0)
generate(2, 2)
