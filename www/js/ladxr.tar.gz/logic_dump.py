import logic
import worldSetup
import bdb


class Options:
    bowwow = ''
    logic = 'normal'
    overworld = 'normal'
    boomerang = 'gift'
    owlstatues = 'none'
    seashells = True
    heartpiece = True
    tradequest = True
    heartcontainers = True
    instruments = False
    witch = True
    dungeon_items = 'normal'
    goal = 8


class Debug(bdb.Bdb):
    def user_line(self, frame):
        for k, v in frame.f_locals.items():
            if isinstance(v, logic.Location) and k not in {"self", "location", "other", "connection"}:
                v.local_name = k


options = Options()
ws = worldSetup.WorldSetup()
d = Debug()
main = d.runcall(logic.Logic, options, world_setup=ws)

def getName(loc):
    result = "N%s" % (id(loc))
    return result

def reqToString(req):
    if req is None:
        return ""
    if isinstance(req, logic.OR):
        result = req._OR__items + req._OR__children
        return "\\n".join([reqToString(s) for s in result])
    if isinstance(req, logic.AND):
        if not req._AND__children:
            return "+".join(req._AND__items)
        result = []
        for r in req._AND__items + req._AND__children:
            if isinstance(r, str):
                result.append(r)
            elif isinstance(r, logic.OR):
                result.append("(%s)" % (reqToString(r).replace("\\n", ",")))
            else:
                result.append(str(r))
        return "+".join(result)
    return str(req)

conn_done = set()
print("graph G {")
for loc in main.location_list:
    if not hasattr(loc, "local_name"):
        loc.local_name = "";
    name = getName(loc)
    for other, req in loc.simple_connections + loc.gated_connections:
        oname = getName(other)
        req = reqToString(req)
        if (oname, name, req) not in conn_done:
            print(f"  {name} -- {oname} [headlabel=\"{req}\"]")
            conn_done.add((name, oname, req))
    label = loc.local_name
    for item in loc.items:
        label += f"\\n{item.metadata.name}"
    print(f"  {name} [label=\"{label}\"]")
for dun in range(1, 10):
    print("  subgraph cluster_%d {" % (dun))
    print("    label=D%d" % (dun))
    print("    bgcolor=lightgray")
    for loc in main.location_list:
        name = getName(loc)
        if loc.dungeon == dun:
            print(f"    {name} [color=\"red\"]")
    print("  }")
print("}")
